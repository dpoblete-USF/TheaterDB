--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "COP4710 Final Project";
--
-- Name: COP4710 Final Project; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "COP4710 Final Project" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE "COP4710 Final Project" OWNER TO postgres;

\connect -reuse-previous=on "dbname='COP4710 Final Project'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: delMovie(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."delMovie"("delMID" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Movies" WHERE "mid" = "delMID") THEN
		RAISE NOTICE 'Cannot delete movie, does not exist';
		RETURN -1;
	ELSIF EXISTS (SELECT * FROM public."Screenings" WHERE "mid" = "delMID") THEN
		RAISE NOTICE 'Cannot delete movie, exists in screening';
		RETURN -2;
	ELSE
		DELETE FROM public."Movies" WHERE "mid" = "delMID";
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."delMovie"("delMID" integer) OWNER TO postgres;

--
-- Name: delTheater(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."delTheater"("delTID" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "tid" = "delTID") THEN
		RAISE NOTICE 'Cannot delete theater, does not exist';
		RETURN -1;
	ELSIF EXISTS (SELECT * FROM public."Screenings" WHERE "tid" = "delTID") THEN
		RAISE NOTICE 'Cannot delete theater, used in other tables';
		RETURN -2;
	ELSIF EXISTS (SELECT * FROM public."Equipment" WHERE "ownedByTid" = "delTID") THEN
		RAISE NOTICE 'Cannot delete theater, used in other tables';
		RETURN -2;
	ELSIF EXISTS (SELECT * FROM public."Employees" WHERE "worksAtTid" = "delTID") THEN
		RAISE NOTICE 'Cannot delete theater, used in other tables';
		RETURN -2;
	ELSIF EXISTS (SELECT * FROM public."Visits" WHERE "tid" = "delTID") THEN
		RAISE NOTICE 'Cannot delete theater, used in other tables';
		RETURN -2;
	ELSE
		RAISE NOTICE 'Theater deleted';
		DELETE FROM public."Theaters" WHERE "tid" = "delTID";
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."delTheater"("delTID" integer) OWNER TO postgres;

--
-- Name: delUser(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."delUser"("delUID" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Users" WHERE "uid" = "delUID") THEN
		RAISE NOTICE 'Cannot delete user, does not exist';
		RETURN -1;
	ELSIF EXISTS (SELECT * FROM public."Visits" WHERE "uid" = "delUID") THEN
		RAISE NOTICE 'Cannot delete user, in the visit table';
		RETURN -2;
	ELSE
		RAISE NOTICE 'Deleted user';
		DELETE FROM public."Users" WHERE "uid" = "delUID";
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."delUser"("delUID" integer) OWNER TO postgres;

--
-- Name: newEmployee(integer, money, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newEmployee"("nTid" integer, "nPay" money, "nFname" text, "nLname" text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "tid" = "nTid") THEN
		RAISE NOTICE 'Cannot add employee, theater does not exist';
		RETURN -1;
	ELSE
		INSERT INTO public."Employees" VALUES (DEFAULT, "nTid", "nPay", "nFname", "nLname");
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."newEmployee"("nTid" integer, "nPay" money, "nFname" text, "nLname" text) OWNER TO postgres;

--
-- Name: newEquipment(text, integer, money, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newEquipment"("nName" text, "nTid" integer, "nPrice" money, "nQnt" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "tid" = "nTid") THEN
		RAISE NOTICE 'Could not add equipment, theater does not exist';
		RETURN -2;
	ELSIF EXISTS (SELECT * FROM public."Equipment" WHERE "ownedByTid" = "nTid" AND "eqname" = "nName" AND "cost" = "nPrice") THEN
		UPDATE public."Equipment" SET "quantity" = "quantity" + "nQnt" WHERE "ownedByTid" = "nTid" AND "eqname" = "nName" AND "cost" = "nPrice";
		RETURN 2;
	ELSE
		INSERT INTO public."Equipment" VALUES (DEFAULT, "nName", "nPrice", "nQnt", "nTid");
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."newEquipment"("nName" text, "nTid" integer, "nPrice" money, "nQnt" integer) OWNER TO postgres;

--
-- Name: newMovie(text, text, time without time zone, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newMovie"("newName" text, "newRating" text, "newLength" time without time zone, "newRlsYear" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Movies" WHERE "mname" = "newName" AND "rating" = "newRating" AND "length" = "newLength" AND "rlsyear" = "newRlsYear") THEN
		INSERT INTO public."Movies" VALUES (DEFAULT, "newName", "newRating", "newLength", "newRlsYear");
		RETURN 1;
	ELSE
		RAISE NOTICE 'Cannot add movie, movie already exists';
		RETURN -1;
	END IF;
END
$$;


ALTER FUNCTION public."newMovie"("newName" text, "newRating" text, "newLength" time without time zone, "newRlsYear" integer) OWNER TO postgres;

--
-- Name: newScreening(integer, integer, integer, date, time without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newScreening"("nMid" integer, "nTid" integer, "nTix" integer, "nDate" date, "nTime" time without time zone) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "tid" = "nTid") THEN
		RAISE NOTICE 'Cannot add screening, theater does not exist';
		RETURN -1;
	ELSIF NOT EXISTS (SELECT * FROM public."Movies" WHERE "mid" = "nMid") THEN
		RAISE NOTICE 'Cannot add screening, movie does not exist';
		RETURN -2;
	ELSE
		INSERT INTO public."Screenings" VALUES (DEFAULT, "nMid", "nTid", "nTix", "nDate", "nTime");
		RETURN 1;
	END IF;
END
$$;


ALTER FUNCTION public."newScreening"("nMid" integer, "nTid" integer, "nTix" integer, "nDate" date, "nTime" time without time zone) OWNER TO postgres;

--
-- Name: newTheater(text, text, money, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newTheater"("newName" text, "newAddr" text, "newPrce" money, "newDisc" double precision) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "address" = "newAddr") THEN
		INSERT INTO public."Theaters" VALUES (DEFAULT, "newName", "newAddr", "newPrce", "newDisc");
		RETURN 1;
	ELSE
		RAISE NOTICE 'Cannot add theater, another already exists at that location';
		RETURN -1;
	END IF;
END
$$;


ALTER FUNCTION public."newTheater"("newName" text, "newAddr" text, "newPrce" money, "newDisc" double precision) OWNER TO postgres;

--
-- Name: newUser(text, text, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newUser"(nfname text, nlname text, nage integer, nemail text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Users" WHERE "email" = "nemail") THEN
		INSERT INTO public."Users" VALUES (DEFAULT, "nfname", "nlname", "nage", "nemail");
		RETURN 1;
	ELSE
		RAISE NOTICE 'Cannot add user, email already used';
		RETURN -1;
	END IF;
END
$$;


ALTER FUNCTION public."newUser"(nfname text, nlname text, nage integer, nemail text) OWNER TO postgres;

--
-- Name: newVisit(date, time without time zone, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."newVisit"("nDate" date, "nTime" time without time zone, "nUid" integer, "nTid" integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NOT EXISTS (SELECT * FROM public."Users" WHERE "uid" = "nUid") THEN
		RAISE NOTICE 'Cannot add visit, user does not exist';
		RETURN -1;
	ELSIF NOT EXISTS (SELECT * FROM public."Theaters" WHERE "tid" = "nTid") THEN
		RAISE NOTICE 'Cannot add visit, theater does not exist';
		RETURN -2;
	ELSIF NOT EXISTS (SELECT * FROM public."Visits" WHERE "tid" = "nTid" AND "uid" = "nUid" AND "date" = "nDate" AND "time" = "nTime") THEN
		INSERT INTO public."Visits" VALUES (DEFAULT, "nTid", "nUid", "nDate", "nTime");
		RETURN 1;
	ELSE
		RAISE NOTICE 'Cannot add visit, exact duplicate of visit being added already exists';
		RETURN -3;
	END IF;
END
$$;


ALTER FUNCTION public."newVisit"("nDate" date, "nTime" time without time zone, "nUid" integer, "nTid" integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employees" (
    empid integer NOT NULL,
    "worksAtTid" integer NOT NULL,
    "hourlyPay" money NOT NULL,
    firstname text NOT NULL,
    lastname text NOT NULL
);


ALTER TABLE public."Employees" OWNER TO postgres;

--
-- Name: Employees_eid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Employees_eid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Employees_eid_seq" OWNER TO postgres;

--
-- Name: Employees_eid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Employees_eid_seq" OWNED BY public."Employees".empid;


--
-- Name: Equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Equipment" (
    eid integer NOT NULL,
    eqname text NOT NULL,
    cost money NOT NULL,
    quantity integer NOT NULL,
    "ownedByTid" integer NOT NULL
);


ALTER TABLE public."Equipment" OWNER TO postgres;

--
-- Name: Equipment_eid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Equipment_eid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Equipment_eid_seq" OWNER TO postgres;

--
-- Name: Equipment_eid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Equipment_eid_seq" OWNED BY public."Equipment".eid;


--
-- Name: Movies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Movies" (
    mid integer NOT NULL,
    mname text NOT NULL,
    rating text NOT NULL,
    length time without time zone NOT NULL,
    rlsyear integer
);


ALTER TABLE public."Movies" OWNER TO postgres;

--
-- Name: Movies_mid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Movies_mid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Movies_mid_seq" OWNER TO postgres;

--
-- Name: Movies_mid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Movies_mid_seq" OWNED BY public."Movies".mid;


--
-- Name: Screenings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Screenings" (
    sid integer NOT NULL,
    mid integer NOT NULL,
    tid integer NOT NULL,
    tickets integer NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL
);


ALTER TABLE public."Screenings" OWNER TO postgres;

--
-- Name: Screenings_sid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Screenings_sid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Screenings_sid_seq" OWNER TO postgres;

--
-- Name: Screenings_sid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Screenings_sid_seq" OWNED BY public."Screenings".sid;


--
-- Name: Theaters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Theaters" (
    tid integer NOT NULL,
    tname text NOT NULL,
    address text NOT NULL,
    tixprice money NOT NULL,
    discount double precision NOT NULL
);


ALTER TABLE public."Theaters" OWNER TO postgres;

--
-- Name: Theaters_tid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Theaters_tid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Theaters_tid_seq" OWNER TO postgres;

--
-- Name: Theaters_tid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Theaters_tid_seq" OWNED BY public."Theaters".tid;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    uid integer NOT NULL,
    firstname text NOT NULL,
    lastname text NOT NULL,
    age integer NOT NULL,
    email text
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Users_uid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_uid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_uid_seq" OWNER TO postgres;

--
-- Name: Users_uid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_uid_seq" OWNED BY public."Users".uid;


--
-- Name: Visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Visits" (
    vid integer NOT NULL,
    tid integer NOT NULL,
    uid integer NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL
);


ALTER TABLE public."Visits" OWNER TO postgres;

--
-- Name: Visits_vid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Visits_vid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Visits_vid_seq" OWNER TO postgres;

--
-- Name: Visits_vid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Visits_vid_seq" OWNED BY public."Visits".vid;


--
-- Name: Employees empid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees" ALTER COLUMN empid SET DEFAULT nextval('public."Employees_eid_seq"'::regclass);


--
-- Name: Equipment eid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment" ALTER COLUMN eid SET DEFAULT nextval('public."Equipment_eid_seq"'::regclass);


--
-- Name: Movies mid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Movies" ALTER COLUMN mid SET DEFAULT nextval('public."Movies_mid_seq"'::regclass);


--
-- Name: Screenings sid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Screenings" ALTER COLUMN sid SET DEFAULT nextval('public."Screenings_sid_seq"'::regclass);


--
-- Name: Theaters tid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Theaters" ALTER COLUMN tid SET DEFAULT nextval('public."Theaters_tid_seq"'::regclass);


--
-- Name: Users uid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN uid SET DEFAULT nextval('public."Users_uid_seq"'::regclass);


--
-- Name: Visits vid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visits" ALTER COLUMN vid SET DEFAULT nextval('public."Visits_vid_seq"'::regclass);


--
-- Data for Name: Employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employees" (empid, "worksAtTid", "hourlyPay", firstname, lastname) FROM stdin;
\.
COPY public."Employees" (empid, "worksAtTid", "hourlyPay", firstname, lastname) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: Equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Equipment" (eid, eqname, cost, quantity, "ownedByTid") FROM stdin;
\.
COPY public."Equipment" (eid, eqname, cost, quantity, "ownedByTid") FROM '$$PATH$$/3101.dat';

--
-- Data for Name: Movies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Movies" (mid, mname, rating, length, rlsyear) FROM stdin;
\.
COPY public."Movies" (mid, mname, rating, length, rlsyear) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: Screenings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Screenings" (sid, mid, tid, tickets, date, "time") FROM stdin;
\.
COPY public."Screenings" (sid, mid, tid, tickets, date, "time") FROM '$$PATH$$/3103.dat';

--
-- Data for Name: Theaters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Theaters" (tid, tname, address, tixprice, discount) FROM stdin;
\.
COPY public."Theaters" (tid, tname, address, tixprice, discount) FROM '$$PATH$$/3105.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (uid, firstname, lastname, age, email) FROM stdin;
\.
COPY public."Users" (uid, firstname, lastname, age, email) FROM '$$PATH$$/3107.dat';

--
-- Data for Name: Visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Visits" (vid, tid, uid, date, "time") FROM stdin;
\.
COPY public."Visits" (vid, tid, uid, date, "time") FROM '$$PATH$$/3109.dat';

--
-- Name: Employees_eid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employees_eid_seq"', 9, true);


--
-- Name: Equipment_eid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Equipment_eid_seq"', 10, true);


--
-- Name: Movies_mid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Movies_mid_seq"', 12, true);


--
-- Name: Screenings_sid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Screenings_sid_seq"', 12, true);


--
-- Name: Theaters_tid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Theaters_tid_seq"', 18, true);


--
-- Name: Users_uid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_uid_seq"', 9, true);


--
-- Name: Visits_vid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Visits_vid_seq"', 11, true);


--
-- Name: Employees Employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees"
    ADD CONSTRAINT "Employees_pkey" PRIMARY KEY (empid);


--
-- Name: Employees Employees_unique_eid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees"
    ADD CONSTRAINT "Employees_unique_eid" UNIQUE (empid);


--
-- Name: Equipment Equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_pkey" PRIMARY KEY (eid);


--
-- Name: Equipment Equipment_unique_eid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_unique_eid" UNIQUE (eid);


--
-- Name: Movies Movies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Movies"
    ADD CONSTRAINT "Movies_pkey" PRIMARY KEY (mid);


--
-- Name: Movies Movies_unique_mid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Movies"
    ADD CONSTRAINT "Movies_unique_mid" UNIQUE (mid);


--
-- Name: Screenings Screenings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Screenings"
    ADD CONSTRAINT "Screenings_pkey" PRIMARY KEY (sid);


--
-- Name: Screenings Screenings_unique_sid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Screenings"
    ADD CONSTRAINT "Screenings_unique_sid" UNIQUE (sid);


--
-- Name: Theaters Theaters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Theaters"
    ADD CONSTRAINT "Theaters_pkey" PRIMARY KEY (tid);


--
-- Name: Theaters Theaters_unique_address; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Theaters"
    ADD CONSTRAINT "Theaters_unique_address" UNIQUE (address);


--
-- Name: Theaters Theaters_unique_tid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Theaters"
    ADD CONSTRAINT "Theaters_unique_tid" UNIQUE (tid);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (uid);


--
-- Name: Users Users_unique_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_unique_email" UNIQUE (email);


--
-- Name: Users Users_unique_uid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_unique_uid" UNIQUE (uid);


--
-- Name: Visits Visits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visits"
    ADD CONSTRAINT "Visits_pkey" PRIMARY KEY (vid);


--
-- Name: Visits Visits_unique_vid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visits"
    ADD CONSTRAINT "Visits_unique_vid" UNIQUE (vid);


--
-- Name: Employees_idx_firstname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Employees_idx_firstname" ON public."Employees" USING btree (firstname text_pattern_ops);


--
-- Name: Employees_idx_lastname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Employees_idx_lastname" ON public."Employees" USING btree (lastname text_pattern_ops);


--
-- Name: Employees_idx_worksAtTid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Employees_idx_worksAtTid" ON public."Employees" USING btree ("worksAtTid");


--
-- Name: Equipment_idx_cost; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Equipment_idx_cost" ON public."Equipment" USING btree (cost);


--
-- Name: Equipment_idx_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Equipment_idx_name" ON public."Equipment" USING btree (eqname text_pattern_ops);


--
-- Name: Equipment_idx_ownedByTid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Equipment_idx_ownedByTid" ON public."Equipment" USING btree ("ownedByTid");


--
-- Name: Movies_idx_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Movies_idx_name" ON public."Movies" USING btree (mname text_pattern_ops);


--
-- Name: Movies_idx_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Movies_idx_rating" ON public."Movies" USING btree (rating text_pattern_ops);


--
-- Name: Movies_idx_rlsyear; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Movies_idx_rlsyear" ON public."Movies" USING btree (rlsyear);


--
-- Name: Screenings_idx_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Screenings_idx_date" ON public."Screenings" USING btree (date);


--
-- Name: Screenings_idx_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Screenings_idx_time" ON public."Screenings" USING btree ("time");


--
-- Name: Theaters_idx_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Theaters_idx_address" ON public."Theaters" USING btree (address text_pattern_ops);


--
-- Name: Theaters_idx_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Theaters_idx_name" ON public."Theaters" USING btree (tname text_pattern_ops);


--
-- Name: Users_idx_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Users_idx_email" ON public."Users" USING btree (email text_pattern_ops);


--
-- Name: Users_idx_firstname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Users_idx_firstname" ON public."Users" USING btree (firstname text_pattern_ops);


--
-- Name: Users_idx_lastname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Users_idx_lastname" ON public."Users" USING btree (lastname text_pattern_ops);


--
-- Name: Visits_fkey_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Visits_fkey_date" ON public."Visits" USING btree (date);


--
-- Name: Visits_idx_tid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Visits_idx_tid" ON public."Visits" USING btree (tid);


--
-- Name: Visits_idx_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Visits_idx_time" ON public."Visits" USING btree ("time");


--
-- Name: Visits_idx_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Visits_idx_uid" ON public."Visits" USING btree (uid);


--
-- Name: employees_idx_fullname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employees_idx_fullname ON public."Employees" USING btree ((((firstname || ' '::text) || lastname)) text_pattern_ops);


--
-- Name: users_idx_fullname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_idx_fullname ON public."Users" USING btree ((((firstname || ' '::text) || lastname)) text_pattern_ops);


--
-- Name: Employees Employees_fkey_worksAtTid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees"
    ADD CONSTRAINT "Employees_fkey_worksAtTid" FOREIGN KEY ("worksAtTid") REFERENCES public."Theaters"(tid) NOT VALID;


--
-- Name: Equipment Equipment_fkey_ownedByTid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_fkey_ownedByTid" FOREIGN KEY ("ownedByTid") REFERENCES public."Theaters"(tid) NOT VALID;


--
-- Name: Screenings Screenings_fkey_mid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Screenings"
    ADD CONSTRAINT "Screenings_fkey_mid" FOREIGN KEY (mid) REFERENCES public."Movies"(mid) NOT VALID;


--
-- Name: Screenings Screenings_fkey_tid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Screenings"
    ADD CONSTRAINT "Screenings_fkey_tid" FOREIGN KEY (tid) REFERENCES public."Theaters"(tid) NOT VALID;


--
-- Name: Visits Visits_fkey_tid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visits"
    ADD CONSTRAINT "Visits_fkey_tid" FOREIGN KEY (tid) REFERENCES public."Theaters"(tid) NOT VALID;


--
-- Name: Visits Visits_fkey_uid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visits"
    ADD CONSTRAINT "Visits_fkey_uid" FOREIGN KEY (uid) REFERENCES public."Users"(uid) NOT VALID;


--
-- PostgreSQL database dump complete
--

